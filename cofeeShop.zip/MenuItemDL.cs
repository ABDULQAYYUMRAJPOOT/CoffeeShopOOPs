﻿using CoffeeShopWeek7.BL;
using CoffeeShopWeek7.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopWeek7.DL
{
    public class MenuItemDL
    {
        public static List<MenuItem> menuItems = new List<MenuItem>();
        public static void addShop(MenuItem item)
        {
            menuItems.Add(item);
        }
        public static void deletDhop(MenuItem item)
        {
            menuItems.Remove(item);
        }
        public static MenuItem getShop(MenuItem item)
        {
            if (menuItems.Count > 0)
            {
                foreach (MenuItem mi in menuItems)
                {
                    if (mi.Equals(item))
                    {
                        return mi;
                    }
                }
            }
            return null;
        }
    }
}

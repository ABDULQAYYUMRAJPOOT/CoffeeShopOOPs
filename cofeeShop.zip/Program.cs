﻿using CoffeeShopWeek7.BL;
using CoffeeShopWeek7.DL;
using CoffeeShopWeek7.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopWeek7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CoffeeShop shop = new CoffeeShop(CoffeeShopUI.getShopName());
            CoffeeShopDL.addShop(shop);
            while (true) {
                int option = CoffeeShopUI.mainMenu();
                if (option == 1)
                {
                    MenuItem item = MenuItemUI.addItem();
                    if (item != null)
                    {
                        shop.addMenuItem(item);
                        continu();
                    }
                    else
                    {
                        invalid();
                    }
                }
                else if (option == 2)
                {
                    Console.WriteLine(shop.cheapestItem());
                    continu();
                }
                else if(option == 3)
                {
                    CoffeeShopUI.showMenu(shop.getDrinkList());
                    continu();
                }
                else if(option == 4)
                {
                    CoffeeShopUI.showMenu(shop.getFoodList());
                    continu();
                }
                else if (option == 5)
                {
                    CoffeeShopUI.getOrder(shop.getMenuList());
                    continu();
                }
                else if (option == 6)
                {
                    Console.WriteLine(shop.fulfillOrder());
                    continu();
                }
                else if (option == 7)
                {
                    CoffeeShopUI.showOrderList(shop.getOrderList());
                    continu();
                }
                else if (option == 8)
                {
                    Console.WriteLine("Total amount of your Orders is: "+shop.dueAmount());
                    continu();
                }
                else if(option == 9)
                {
                    break;
                }
            }
        }
        static void invalid()
        {
            Console.WriteLine("Invalid Input...");
            Console.ReadKey();
        }
        static void continu()
        {
            Console.Write("Press any key to Continue...");
            Console.ReadKey();
        }
    }
        

}

﻿using CoffeeShopWeek7.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopWeek7.DL
{
    public class CoffeeShopDL
    {
        static List<CoffeeShop> CoffeeShops = new List<CoffeeShop>();
        public static void addShop(CoffeeShop shop)
        {
            CoffeeShops.Add(shop);
        }
        public static void deletDhop(CoffeeShop shop)
        {
            CoffeeShops.Remove(shop);
        }
        public static CoffeeShop getShop(CoffeeShop shop)
        {
            if (CoffeeShops.Count > 0)
            {
                foreach(CoffeeShop sh in CoffeeShops)
                {
                    if(sh.Equals(shop))
                    {
                        return sh;
                    }
                }
            }
            return null;
        }
    }
}

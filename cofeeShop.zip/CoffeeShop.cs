﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopWeek7.BL
{
    public class CoffeeShop
    {
        public string Name;
        public static List<MenuItem> Menu;
        public static List<string> Orders;
        public CoffeeShop(string name)
        {
            Name = name;
            Menu = new List<MenuItem>();
            Orders = new List<string>();
        }
        public List<string> getOrderList()
        {
            return Orders;
        }
        public List<MenuItem> getMenuList()
        {
            return Menu;
        }
        public void addMenuItem(MenuItem item)
        {
            Menu.Add(item);
        }
        public bool checkItemInMenu(string name)
        {
            foreach(MenuItem item in Menu)
            {
                if(name.Equals(item.Name))
                {
                    return true;
                }
            }
            return false;
        }
        public string addOrder(string order)
        {
            if(checkItemInMenu(order))
            {
                Orders.Add(order);
                return null;
            }
            else
            {
                return "This item is currently unavailable!";
            }
        }
        public string fulfillOrder()
        {
            string result = "";
            if(Orders.Count>0)
            {
               foreach(string item in Orders)
                {
                    result = result + "This " + item + " is ready!\n";
                }
                
            }
            else
            {
                result = "All orders have been fulfilled";
            }
            return result;
            
        }
        public List<string> listOrders()
        {
            if(Orders!= null)
            {
                return Orders;

            }
            else
            {
                return null;
            }
        }

        public float dueAmount()
        {
            float result = 0f;
           
            foreach(var name in Orders)
            {
                foreach(MenuItem item in Menu)
                {
                    if(name.Equals(item.Name))
                    {
                    result = result + item.Price;
                    }
                }
            }
            
            return result;
        }
        public string cheapestItem()
        {
            List<MenuItem> sortedList = Menu.OrderByDescending(x => x.Price).ToList();
            string str = sortedList[0].Name + "\t" + sortedList[0].Type + "\t" + sortedList[0].Price;
            return str;
        }
        public void addItemsListInMenuList(List<MenuItem> drinks)
        {
            Menu.AddRange(drinks);
        }
        public List<MenuItem> getDrinkList()
        {
            List<MenuItem> drinks = new List<MenuItem>();
            foreach(MenuItem item in Menu) 
            {
                if(item.Type.Equals("drink"))
                {
                    drinks.Add(item);
                }
            }
            return drinks;
        }
        public List<MenuItem> getFoodList()
        {
            List<MenuItem> food = new List<MenuItem>();
            foreach(MenuItem item in Menu) 
            {
                if(item.Type.Equals("food"))
                {
                    food.Add(item);
                }
            }
            return food;
        }
    }
}

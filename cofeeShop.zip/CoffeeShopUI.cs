﻿using CoffeeShopWeek7.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopWeek7.UI
{
    public class CoffeeShopUI
    {
        public static int mainMenu()
        {
            int option;
            Console.WriteLine("1. Add a Menu Item");
            Console.WriteLine("2. View the Cheapest Item in the menu");
            Console.WriteLine("3. View the Drink's Menu");
            Console.WriteLine("4. View the Food's Menu");
            Console.WriteLine("5. Add Order");
            Console.WriteLine("6. Fulfill the Order");
            Console.WriteLine("7. View the Order's List");
            Console.WriteLine("8. Total Payable Amount");
            Console.WriteLine("9. Exit");
            return option = int.Parse(Console.ReadLine());

        }
        public static void showCheapestItem(MenuItem item)
        {
            Console.WriteLine();
            Console.WriteLine(item.Name + "\t" + item.Type + "\t" + item.Price);
        }
        public static void showMenu(List<MenuItem> items)
        {
            int i = 1;
            foreach(MenuItem item in items) 
            {
                Console.WriteLine(i + ". "+item.Name + "\t" + item.Type + "\t" + item.Price) ;
                i++;
            }
        }
        public static MenuItem getOrder(List<MenuItem> list)
        {
            int option;
            showMenu(list);
            Console.Write("Enter item number to Order: ");
            option = int.Parse(Console.ReadLine());
            return list[option - 1];
        }
        public static string getShopName()
        {
            Console.Write("Enter name of your Shop: ");
            string str = Console.ReadLine();
            return str;
        }
        public static void showOrderList(List<string> orders)
        {
            int i = 1;
            foreach(string order in orders)
            {
                Console.WriteLine(i+". "+order);
                i++;
            }
        }
    }
}

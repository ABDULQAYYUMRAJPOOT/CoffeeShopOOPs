﻿using CoffeeShopWeek7.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopWeek7.UI
{
    public class MenuItemUI
    {
        public static MenuItem addItem()
        {
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter Type of Item: ");
            string type = Console.ReadLine();
            Console.Write("Enter Price of Item: ");
            float price = float.Parse(Console.ReadLine());
            MenuItem item = new MenuItem(name, type, price);
            if(price > 0 && name != null && type != null)
            {
                return item;
            }
            return null;
        }
    }
}
